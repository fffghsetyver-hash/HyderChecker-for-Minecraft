import eel, os, sys, subprocess, psutil, base64

# Магия для того, чтобы .exe видел папку web и зашитые внутри утилиты
if getattr(sys, 'frozen', False):
    base_dir = sys._MEIPASS
else:
    base_dir = os.path.dirname(os.path.abspath(__file__))

eel.init(os.path.join(base_dir, 'web'))

def get_size_format(b):
    for unit in ["", "K", "M", "G"]:
        if b < 1024: return f"{b:.2f}{unit}B"
        b /= 1024
    return f"{b:.2f}TB"

@eel.expose
def search_in_logs(query):
    if not query or len(query) < 2: return []
    appdata = os.getenv('APPDATA')
    paths = [os.path.join(appdata, ".minecraft", "logs"), os.path.join(appdata, ".tlauncher", "legacy", "Minecraft", "game", "logs")]
    results = []
    for p in paths:
        if os.path.exists(p):
            for file in os.listdir(p):
                if file.endswith(('.log', '.txt')):
                    try:
                        with open(os.path.join(p, file), 'r', encoding='utf-8', errors='ignore') as f:
                            if query.lower() in f.read().lower():
                                results.append(f"📄 {file} | {os.path.getsize(os.path.join(p, file))//1024}KB")
                    except: continue
    return results if results else ["Ничего не найдено внутри файлов"]

@eel.expose
def deep_system_scan():
    keywords = ['vape', 'expensive', 'nursultan', 'cheat', 'hack', 'neverhook', 'akrien', 'celestial']
    reports = []
    # Проверка Prefetch
    pf = r"C:\Windows\Prefetch"
    try:
        if os.path.exists(pf):
            files = [f for f in os.listdir(pf) if any(k in f.lower() for k in keywords)]
            for f in files: reports.append(f"PF-TRACE: {f}")
    except: reports.append("❌ Нет доступа к Prefetch")
    
    # Проверка Temp
    temp = os.getenv('TEMP')
    try:
        if temp and os.path.exists(temp):
            for f in os.listdir(temp):
                if any(k in f.lower() for k in keywords): reports.append(f"TEMP-FILE: {f}")
    except: pass
    return reports if reports else ["Системных следов не найдено"]

@eel.expose
def get_folder_content(path_type):
    appdata = os.getenv('APPDATA')
    mcp = os.path.join(appdata, ".minecraft")
    tlp = os.path.join(appdata, ".tlauncher", "legacy", "Minecraft", "game")
    
    search_paths = {
        'mods': [os.path.join(mcp, "mods"), os.path.join(tlp, "mods")],
        'versions': [os.path.join(mcp, "versions"), os.path.join(tlp, "versions")],
        'logs': [os.path.join(mcp, "logs")]
    }
    
    result = []
    if path_type in search_paths:
        for p in search_paths[path_type]:
            if os.path.exists(p):
                file_data = []
                try:
                    for item in os.listdir(p):
                        full_p = os.path.join(p, item)
                        size = ""
                        # Защита от системных блокировок Windows
                        try:
                            if path_type == 'versions' and os.path.isdir(full_p):
                                for sub in os.listdir(full_p):
                                    if sub.endswith(".jar"):
                                        size = f" | {get_size_format(os.path.getsize(os.path.join(full_p, sub)))}"
                                        break # Нашли первый .jar и прерываем цикл (ускоряет работу)
                            elif os.path.isfile(full_p):
                                size = f" | {get_size_format(os.path.getsize(full_p))}"
                        except Exception:
                            pass # Игнорируем файлы, которые заблокированы игрой или ОС
                            
                        file_data.append(f"{item}{size}")
                    result.append({"path": p, "files": file_data})
                except Exception:
                    continue # Игнорируем папки без доступа
    return result

@eel.expose
def check_processes():
    suspicious = ['vape', 'expensive', 'nursultan', 'neverhook', 'deadcode', 'akrien', 'impact', 'meteor', 'liquidbounce']
    found = []
    for p in psutil.process_iter(['name']):
        try:
            if any(x in p.info['name'].lower() for x in suspicious):
                found.append(p.info['name'])
        except: continue
    return found if found else ["Активных читов не обнаружено"]

@eel.expose
def get_dns():
    try:
        output = subprocess.check_output('ipconfig /displaydns', shell=True).decode('cp866', errors='ignore')
        bad = ['vape', 'cheat', 'hack', 'expensive', 'nursultan', 'neverlose', 'intent.store']
        found = [line.strip() for line in output.splitlines() if any(s in line.lower() for s in bad)]
        return found if found else ["DNS История чиста"]
    except: return ["Ошибка чтения DNS"]

@eel.expose
def get_screenshots():
    p_base = os.getenv('APPDATA')
    paths = [os.path.join(p_base, ".minecraft", "screenshots"), os.path.join(p_base, ".tlauncher", "legacy", "Minecraft", "game", "screenshots")]
    imgs = []
    for p in paths:
        if os.path.exists(p):
            try:
                files = [os.path.join(p, f) for f in os.listdir(p) if f.lower().endswith(('.png','.jpg'))]
                files.sort(key=os.path.getmtime, reverse=True)
                for f in files[:20]:
                    with open(f, "rb") as i: imgs.append(f"data:image/png;base64,{base64.b64encode(i.read()).decode()}")
            except: continue
    return imgs

@eel.expose
def run_soft(name):
    try:
        # Ищем программу в нашей распакованной папке .exe файла
        soft_path = os.path.join(base_dir, name)
        if os.path.exists(soft_path):
            os.startfile(soft_path)
        else:
            os.system(f"start {name}")
    except:
        os.system(f"start {name}")

# --- ЗАПУСК ПРОГРАММЫ ---
flags = ['--start-maximized', '--no-sandbox']
try:
    eel.start('index.html', mode='chrome', cmdline_args=flags)
except:
    try: eel.start('index.html', mode='edge', cmdline_args=flags)
    except: eel.start('index.html', mode='default')