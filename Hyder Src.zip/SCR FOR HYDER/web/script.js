// --- ЛОКАЛИЗАЦИЯ ---
const i18n = {
    ru: {
        intro: "ДОБРО ПОЖАЛОВАТЬ",
        nav1: "🏠 ГЛАВНОЕ МЕНЮ", nav2: "🖥️ АНАЛИЗ СИСТЕМЫ", nav3: "📁 ПРОВОДНИК ИГРЫ",
        nav4: "📜 ГЛУБОКИЙ ПОИСК ЛОГОВ", nav5: "📸 ГАЛЕРЕЯ СКРИНОВ",
        tab1_h2: "Панель быстрого доступа", utils: "🛠️ УТИЛИТЫ", res_title: "🔗 РЕСУРСЫ",
        btn_regex1: "📋 Скопировать Regex Читов", btn_regex2: "📝 Скопировать Regex Конфигов",
        sys_h2: "Анализ ОС и Памяти",
        btn_proc: "⚡ Активные Процессы", btn_dns: "🌐 DNS История", btn_deep: "🕵️ Глубокий поиск (PF/Temp)",
        exp_h2: "Внутренний Проводник Minecraft",
        btn_mods: "📂 Моды", btn_ver: "📂 Версии (+Размер)",
        logs_h2: "Глубокий поиск ПО ТЕКСТУ логов",
        media_h2: "Скриншоты из игры", btn_refresh: "🔄 Обновить Галерею"
    },
    en: {
        intro: "WELCOME",
        nav1: "🏠 MAIN MENU", nav2: "🖥️ SYSTEM ANALYSIS", nav3: "📁 GAME EXPLORER",
        nav4: "📜 DEEP LOG SEARCH", nav5: "📸 MEDIA GALLERY",
        tab1_h2: "Quick Access Panel", utils: "🛠️ UTILITIES", res_title: "🔗 RESOURCES",
        btn_regex1: "📋 Copy Cheats Regex", btn_regex2: "📝 Copy Configs Regex",
        sys_h2: "OS & Memory Analysis",
        btn_proc: "⚡ Active Processes", btn_dns: "🌐 DNS History", btn_deep: "🕵️ Deep Scan (PF/Temp)",
        exp_h2: "Internal Minecraft Explorer",
        btn_mods: "📂 Mods", btn_ver: "📂 Versions (+Size)",
        logs_h2: "Deep Text LOG Search",
        media_h2: "In-game Screenshots", btn_refresh: "🔄 Refresh Gallery"
    }
};

function setLang(lang) {
    document.querySelectorAll('[data-lang]').forEach(el => {
        const key = el.getAttribute('data-lang');
        if (i18n[lang][key]) el.innerHTML = i18n[lang][key];
    });
    
    // Скрываем выбор языка, запускаем интро
    document.getElementById('lang_screen').style.display = 'none';
    const intro = document.getElementById('intro_screen');
    intro.style.display = 'flex';
    
    // Через 2.5 сек открываем основную прогу
    setTimeout(() => { 
        intro.style.display = 'none';
        document.getElementById('main_wrapper').style.display = 'flex'; 
    }, 2500);
}

// --- ЛОГИКА ИНТЕРФЕЙСА ---
function switchTab(id) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById(id).classList.add('active');
}

async function runProcessCheck() {
    document.getElementById('system_console').innerHTML = "Сканирую память...";
    const res = await eel.check_processes()();
    document.getElementById('system_console').innerHTML = res.join('<br>');
}

async function runDnsCheck() {
    document.getElementById('system_console').innerHTML = "Опрашиваю кэш DNS...";
    const res = await eel.get_dns()();
    document.getElementById('system_console').innerHTML = res.join('<br>');
}

async function runDeepSystemCheck() {
    document.getElementById('system_console').innerHTML = "Глубокое сканирование Prefetch/Temp...";
    const res = await eel.deep_system_scan()();
    document.getElementById('system_console').innerHTML = res.join('<br>');
}

async function doDeepLogSearch() {
    const q = document.getElementById('log_input').value;
    if(q.length < 2) return;
    document.getElementById('log_results').innerHTML = "Поиск внутри файлов (это может занять время)...";
    const res = await eel.search_in_logs(q)();
    document.getElementById('log_results').innerHTML = res.join('<br>');
}

async function loadFolder(type) {
    const layout = document.getElementById('explorer_layout');
    layout.innerHTML = "Загрузка папок...";
    const data = await eel.get_folder_content(type)();
    layout.innerHTML = "";
    layout.style.gridTemplateColumns = data.length > 1 ? "1fr 1fr" : "1fr";
    data.forEach(item => {
        const p = document.createElement('div');
        p.style = "background:rgba(0,0,0,0.9); border:1px solid #333; padding:15px; border-radius:10px; height:500px; overflow-y:auto;";
        p.innerHTML = `<h4 style="color:#00d4ff; border-bottom:1px solid #222; padding-bottom:5px;">📍 ${item.path}</h4>` + 
                      item.files.map(f => `<div style="color:#0f0; font-family:monospace; font-size:12px; border-bottom:1px solid #111; padding:4px 0;">📄 ${f}</div>`).join('');
        layout.appendChild(p);
    });
}

async function loadScreenshots() {
    const grid = document.getElementById('media_grid');
    grid.innerHTML = "Подгружаю снимки...";
    const res = await eel.get_screenshots()();
    grid.innerHTML = res.map(src => `<img src="${src}">`).join('');
}

function copyRegex(n) {
    const r = n === 1 ? "ext:.exe;.jar;.zip regex:(vape|expensive|nursultan|neverhook|liquidbounce|meteor|impact|akrien|celestial)" : "ext:.json;.cfg;.txt regex:(config|settings|vape|nursultan|expensive)";
    navigator.clipboard.writeText(r);
    const ntf = document.getElementById('copy_notif');
    ntf.style.display='block'; setTimeout(() => ntf.style.display='none', 2000);
}

// --- КОСМОС И ЭФФЕКТЫ ---
const sky = document.getElementById('space_bg');
for(let i=0; i<150; i++){
    const s = document.createElement('div'); s.className = 'star';
    s.style.width = s.style.height = Math.random()*2+'px';
    s.style.left = Math.random()*100+'vw'; s.style.top = Math.random()*100+'vh';
    s.style.animationDuration = (Math.random()*40+40)+'s'; sky.appendChild(s);
}
setInterval(() => {
    const m = document.createElement('div'); m.className = 'meteor'; m.style.left = Math.random()*100+'vw';
    sky.appendChild(m); setTimeout(() => m.remove(), 10000);
}, 6000);